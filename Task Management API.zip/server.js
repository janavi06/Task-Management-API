const express = require("express");
const { request } = require("node:http");
const { Pool } = require("pg");

const pool = new Pool({
    user: "postgress",
    host: "localhost",
    database: "task_management",
    password: "Janavi06122005",
    port: 5432
})

const app = express();

pool.query("SELECT NOW()")
    .then(result => {
        console.log(result.rows);
    })
    .catch(error => {
        console.log(error);
    });

app.use(express.json());

const task = [];
let nextId = 1;

app.get("/", (request, response) => {
    response.send("API is running");
});

app.get("/tasks", async (request,response) => {
    const result = await pool.query("SELECT * FROM tasks");
})

app.get("/tasks/:id", (request, response) => {
    const id = Number(request.params.id);

    const task = tasks.find(task => task.id === id);

    if (task === undefined) {
        response.status(404).send("Not found");
    } else {
        response.send(task);
    }
});

app.post("/tasks", (request, response) => {
    const task = {
        id: nextId,
        tile: request.body.title
    };
    nextId++;
    task.push(task);  // add that into our object
    response.status(201).send(task);
})

app.patch("/tasks/:id", (request, response) => {
    const id = Number(request.params.id);

    const task = tasks.find(task => task.id === id);

    if (task === undefined){
        response.status(404).send("Not found");
    } else {
        task.title = request.body.title;
        response.send(task);
    }
});

app.delete("/tasks/:id", (request, response) => {
    const id = Number(request.params.id);
    const index = tasks.findIndex(task => task.id === id);

    if (index === -1){
        response.status(404).send("Not found");
    } else {
        tasks.splice(index, 1);
        response.send("task deleted");
    }
})

app.listen(3000, () => {
    console.log("Server is running on port 3000");
})


// if (typeof request.body.title !== "string"){
//     response.status(400).send("Invalid title")
// } else if ( request.body.title.trim().length === 0){
//     response.status(400).send("Invalid String")
// }